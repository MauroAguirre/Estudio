//
//  GXModule_GeneXus.h
//  GXModule_GeneXus
//
//  Copyright 2016 GeneXus. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GXModule_GeneXus.
FOUNDATION_EXPORT double GXModule_GeneXusVersionNumber;

//! Project version string for GXModule_GeneXus.
FOUNDATION_EXPORT const unsigned char GXModule_GeneXusVersionString[];

#import <GXModule_GeneXus/GXGlobalImports.h>


