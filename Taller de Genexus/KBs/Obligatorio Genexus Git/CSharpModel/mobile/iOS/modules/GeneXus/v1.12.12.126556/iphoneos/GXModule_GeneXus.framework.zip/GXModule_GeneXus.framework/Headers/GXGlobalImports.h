//
//  GXGlobalImports.h
//  GXModule_GeneXus
//
//  Copyright 2016 GeneXus. All rights reserved.
//

#ifndef GXGlobalImports_h
#define GXGlobalImports_h

@import GXAudioBL;
#if TARGET_OS_IOS
@import GXAudioUI;
#endif // TARGET_OS_IOS
@import GXCoreBL;
#if TARGET_OS_IOS
@import GXCoreModule_Common_Analytics;
#endif // TARGET_OS_IOS
@import GXCoreModule_Common_GeoLocation;
#if TARGET_OS_IOS || TARGET_OS_TV
@import GXCoreModule_Common_Log;
#endif // TARGET_OS_IOS || TARGET_OS_TV
#if TARGET_OS_IOS
@import GXCoreModule_SD_Beacons;
@import GXCoreModule_SD_Calendar;
#endif // TARGET_OS_IOS
@import GXCoreModule_SD_Contacts;
#if TARGET_OS_IOS
@import GXCoreModule_SD_DeviceAuthentication;
@import GXCoreModule_SD_Media_PhotoLibrary;
#endif // TARGET_OS_IOS
@import GXCoreModule_SD_Notifications;
#if TARGET_OS_IOS
@import GXCoreModule_SD_Scanner;
#endif // TARGET_OS_IOS
#if TARGET_OS_IOS || TARGET_OS_TV
@import GXCoreModule_SD_Store;
#endif // TARGET_OS_IOS || TARGET_OS_TV
@import GXCoreModule_SD_Synchronization;
@import GXCoreUI;
@import GXDataLayer;
@import GXFoundation;
@import GXObjectsModel;
@import GXStandardClasses;
@import YAJL;


#endif /* GXGlobalImports_h */